The custom sky requires FabricSkyboxes (Fabric/Quilt) or Optifine (Forge) to work properly.
Use ETF (Entity Texture Features Mod) to prevent glitching models/textures which may occur when not using Optifine.



Patchnotes V1.1:
-There's a shader friendly version now! Use it if the sky looks weird when using a shader and the texturepack at the same time (or if you just want the full version but no custom sky)
-Removed the 3d Potion models & fixed potion texture
-Added compatibility with glass culling texturepacks
-Removed some 3d inventory models so the inventory UI on servers looks decent again (this only affects items in inventory slots/item frames, the actual blocks still have the same model as before)
-Removed the admittedly weird custom models of swords and shovels (crossbow is still there, don't worry)
-fixed the compass model
-sun and moon are smaller now (because I think they were way too big, especially the moon)
-drastically decreased file size of the "low" version (it's less than 0.5mb now!)



Credit to
-Hyper Realistic Sky 1.9 (Shader_OFF assets)
-BetterTooltip
-Vanilla Tweaks