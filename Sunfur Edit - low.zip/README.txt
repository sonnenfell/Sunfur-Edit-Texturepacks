The custom sky requires FabricSkyboxes (Fabric/Quilt) or Optifine (Forge) to work properly.
Use ETF (Entity Texture Features Mod) to prevent glitching models/textures which may occur when not using Optifine.



Credit to...

-Hyper Realistic Sky 1.9 (Shader_OFF assets)
-BetterTooltip
-Vanilla Tweaks

(...because i copied some of their assets)