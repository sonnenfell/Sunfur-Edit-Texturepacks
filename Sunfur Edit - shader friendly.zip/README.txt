Ok so WTF is "Sunfur Edit - shader friendly"? Why and when do I need it? There's already a full and low version, so what's so different about a "shader friendly" version?

The answer to these questions is pretty simple: The full version (Sunfur Edit)  comes with a built-in custom sky. Shaders come with custom skies too. Now, if you want to use a shader with a custom sky and the texturepack at the same time, the shader packs custom sky effect gets applied on top of the custom sky from the texturepack that's already there - as a result, the sky looks really weird (like extremely oversaturated of way too bright). Some shaders have the option to automatically turn off your resourcepack's custom sky so this problem doesn't occur, but not all of them. That's what this pack is for.
TLDR:
THIS SHADER FRIENDLY VERSION REMOVES THE TEXTUREPACKS CUSTOM SKY SO IT DOESN'T CONFLICT WITH ANY SHADERS YOU MAY APPLY. Everything else, including all textures and models, is exactly the same as in the full version.



Use ETF (Entity Texture Features Mod) to prevent glitching models/textures which may occur when not using Optifine.


Patchnotes V1.1:
-There's a shader friendly version now! Use it if the sky looks weird when using a shader and the texturepack at the same time (or if you just want the full version but no custom sky)
-Removed the 3d Potion models & fixed potion texture
-Added compatibility with glass culling texturepacks
-Removed some 3d inventory models so the inventory UI on servers looks decent again (this only affects items in inventory slots/item frames, the actual blocks still have the same model as before)
-Removed the admittedly weird custom models of swords and shovels (crossbow is still there, don't worry)
-fixed the compass model
-sun and moon are smaller now (because I think they were way too big, especially the moon)
-drastically decreased file size of the "low" version (it's less than 0.5mb now!)



Credit to
-Hyper Realistic Sky 1.9 (Shader_OFF assets)
-BetterTooltip
-Vanilla Tweaks